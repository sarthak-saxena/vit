<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Welcome to VIT CMS</title>
</head>
<body>

	<h1>Welcome to VIT Official Website(www.vit.ac.in) CMS!</h1>

	<h3>Version 0.0.1 (initial build)</h3>

	<p>
		This CMS is the central control system for inserting or updating data on the database and also define what dynamic contents are required to be displayed in the main website.
	</p>

	<p>
		[Note] *For realtime use, follow the actual implementation documentation.
	</p>

	<p>
		Developed by:
		AlfaInifinity Inc. 2015
	</p>

</body>
</html>
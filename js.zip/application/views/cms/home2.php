<!-- cms page -->
<div ng-controller="aboutController" data-ng-init="init()">

	Hello World

</div>

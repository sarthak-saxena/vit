<footer>
    <div class="footer-relative">
      <div class="container">
        <div class="row text-muted">
          <center>
            <div class="col-sm-4">
              <b>Copyright: &copy; VIT University 2015</b>
            </div>
            <div class="col-sm-4" id="vDet">
              <b>Version: 0.0.1 </b>&nbsp;(Initial Build)
            </div>
            <div class="col-sm-4">
              <b>Developed By: AlfaInfinity Pvt Ltd 2015</b>
            </div>
          </center>
        </div>
      </div>
    </div>
  </footer><!-- End of footer -->

    <!-- All Javascript at the bottom of the page for faster page loading -->
    
    <!-- First try for the online version of jQuery-->
    <script src="/vit/js/jquery-2.1.3.min.js"></script>
      
    <!-- Bootstrap JS -->
    <script src="/vit/bootstrap/js/bootstrap.min.js"></script>
      
    <script src="/vit/js/jasny-bootstrap.min.js"></script>
    <script src="//code.jquery.com/ui/1.11.1/jquery-ui.js"></script>
      
    <!-- Custom JS -->
    <script src="/vit/js/custom_cms.js"></script>

	</body>
</html>